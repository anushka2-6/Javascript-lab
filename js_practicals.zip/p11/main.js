import Scheduler, { formatTime, startCountdown, pad } from "./timer.js";

// ----- Live clock (setInterval) -----
const clock = document.getElementById("clock");
setInterval(() => {
  const d = new Date();
  clock.textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}, 1000);

// ----- Countdown -----
let timerId;
document.getElementById("start").addEventListener("click", () => {
  const secs = Number(document.getElementById("secs").value);
  if (secs <= 0) return alert("Seconds daalein");
  clearInterval(timerId);
  const target = Date.now() + secs * 1000;
  const out = document.getElementById("cd");
  timerId = startCountdown(target, ms => out.textContent = formatTime(ms), () => {
    out.textContent = "Time up! ⏰";
    // setTimeout: message 3 sec baad hatao
    setTimeout(() => out.textContent = "00:00:00", 3000);
  });
});
document.getElementById("stop").addEventListener("click", () => clearInterval(timerId));

// ----- Class scheduler (minutes from midnight) -----
const classes = [
  { name: "JavaScript", start: 9 * 60, end: 10 * 60 + 30 },
  { name: "Web Design", start: 11 * 60, end: 12 * 60 + 30 },
  { name: "Database", start: 14 * 60, end: 15 * 60 + 30 },
  { name: "Project Lab", start: 16 * 60, end: 18 * 60 }
];
const sch = new Scheduler(classes);
const fmt = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
function renderSchedule() {
  document.getElementById("sched").innerHTML = sch.classes.map(c => {
    const st = sch.status(c);
    return `<li class="${st}"><b>${c.name}</b> (${fmt(c.start)}-${fmt(c.end)}) <span>${st}</span></li>`;
  }).join("");
}
renderSchedule();
setInterval(renderSchedule, 1000);
