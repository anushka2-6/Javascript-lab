// ES6 module: timer utilities
export const pad = n => String(n).padStart(2, "0");

export function formatTime(ms) {
  if (ms <= 0) return "00:00:00";
  const s = Math.floor(ms / 1000);
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

export function startCountdown(targetDate, onTick, onDone) {
  const id = setInterval(() => {
    const left = targetDate - Date.now();
    if (left <= 0) { clearInterval(id); onTick(0); onDone(); return; }
    onTick(left);
  }, 1000);
  return id;
}

export default class Scheduler {
  constructor(classes) { this.classes = classes; }
  status(c, now = new Date()) {
    const mins = now.getHours() * 60 + now.getMinutes();
    if (mins < c.start) return "Upcoming";
    if (mins < c.end) return "Ongoing";
    return "Completed";
  }
}
