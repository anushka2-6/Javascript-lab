JavaScript Practicals (1-12)
Har folder me index.html kholo (double click).
P10 (fetch) aur P11 (ES modules) ke liye local server zaroori hai:
  python -m http.server 8000   -> http://localhost:8000/p10/  aur /p11/
VS Code me "Live Server" extension bhi use kar sakte ho.
