// External JS file
const info = document.getElementById("info");
info.innerHTML = `<p><b>Name:</b> ${user.name}</p><p><b>Age:</b> ${user.age}</p><p><b>City:</b> ${user.city}</p>`;

// Console methods
console.log("Normal log");
console.info("Info message");
console.warn("Warning message");
console.error("Error message");
console.table(user);
console.group("Group Example");
console.log("Inside group 1");
console.log("Inside group 2");
console.groupEnd();
console.time("loop");
for (let i = 0; i < 100000; i++) {}
console.timeEnd("loop");
console.assert(user.age > 25, "Age 25 se zyada nahi hai");
